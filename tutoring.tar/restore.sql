--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "tutoring-dev";
--
-- Name: tutoring-dev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "tutoring-dev" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE "tutoring-dev" OWNER TO postgres;

\connect -reuse-previous=on "dbname='tutoring-dev'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgagent; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pgagent;


ALTER SCHEMA pgagent OWNER TO postgres;

--
-- Name: SCHEMA pgagent; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA pgagent IS 'pgAgent system tables';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: pgagent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgagent WITH SCHEMA pgagent;


--
-- Name: EXTENSION pgagent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgagent IS 'A PostgreSQL job scheduler';


--
-- Name: event_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.event_type AS (
	provider_id character varying,
	start_time time without time zone,
	end_time time without time zone,
	period_freq integer,
	period_typeid character varying,
	start_date date,
	end_date date
);


ALTER TYPE public.event_type OWNER TO postgres;

--
-- Name: overlap_instance_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.overlap_instance_type AS (
	provider_id character varying,
	customer_id character varying,
	eventid integer,
	instanceid integer,
	start_time time without time zone,
	end_time time without time zone,
	start_date date,
	end_date date,
	event_date date,
	description text,
	exception_desc text
);


ALTER TYPE public.overlap_instance_type OWNER TO postgres;

--
-- Name: get_appointment_instances(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_appointment_instances(start_date_param character varying, end_date_param character varying, except_rbs_event_id integer, except_rbs_instance_id integer) RETURNS TABLE(provider_id character varying, customer_id character varying, eventid integer, instanceid integer, start_time time without time zone, end_time time without time zone, event_date text, description text, event_cancelled integer, exception_desc character varying, start_date date, end_date date, period_freq integer)
    LANGUAGE plpgsql
    AS $$
BEGIN

return query 
	with final_table as
	(SELECT 
		distinct qryEventCartesian.provider_id,
		qryEventCartesian.customer_id,
		qryEventCartesian.EventID, 
		qryEventCartesian.InstanceID, 
		case 
			when schedule_appointment_override.event_id Is Null 
			then 
				qryEventCartesian.start_time
			else 
				case
					when schedule_appointment_override.event_cancelled=1
					then Null
					else schedule_appointment_override.new_start_time
			end
		end start_time,
			case
				when schedule_appointment_override.event_id Is Null
				then
					qryEventCartesian.end_time
				else
					case
						when schedule_appointment_override.event_cancelled=1
						then Null
						else schedule_appointment_override.new_end_time
			end
		end end_time,
		TO_CHAR(case 
			when schedule_appointment_override.event_id Is Null 
			then 
				case
					when (qryEventCartesian.period_typeid Is Null) Or (qryEventCartesian.period_freq Is Null) Or (qryEventCartesian.InstanceID Is Null)
					then qryEventCartesian.start_date
					else 
						temperal_add(
							qryEventCartesian.start_date, 
							qryEventCartesian.InstanceID*qryEventCartesian.period_freq,
							qryEventCartesian.period_typeid)
				end 
			else 
				case
					when schedule_appointment_override.event_cancelled=1
					then temperal_add(
							qryEventCartesian.start_date,
							qryEventCartesian.InstanceID*qryEventCartesian.period_freq,
							qryEventCartesian.period_typeid)
					else schedule_appointment_override.new_date
				end
		end, 'yyyy-mm-dd') AS event_date,
		qryEventCartesian.description, 
		schedule_appointment_override.event_cancelled, 
		schedule_appointment_override.description as exception_desc, 
		qryEventCartesian.start_date, 
		qryEventCartesian.end_date, 
		qryEventCartesian.period_freq
	FROM (
		(SELECT 
			schedule_appointment.event_id AS EventID, 
			tbl_instants.id AS InstanceID, 
			schedule_appointment.description, 
			schedule_appointment.start_date, 
			schedule_appointment.end_date, 
			schedule_appointment.period_freq, 
			schedule_appointment.period_typeid, 
			schedule_appointment.start_time,
			schedule_appointment.end_time,
			schedule_appointment.provider_id,
			schedule_appointment.customer_id
		FROM schedule_appointment, get_instance_seed_table(100) as tbl_instants
		WHERE 
			(schedule_appointment.end_date IS Null OR
			schedule_appointment.end_date >=temperal_add(schedule_appointment.start_date, tbl_instants.id, schedule_appointment.period_typeid))
			and schedule_appointment.is_enable=1 and schedule_appointment.date_deleted is null
		ORDER BY 
			schedule_appointment.event_id) AS qryEventCartesian 
			LEFT JOIN schedule_appointment_override 
				ON (qryEventCartesian.InstanceID = schedule_appointment_override.instance_id) 
					AND (qryEventCartesian.EventID = schedule_appointment_override.event_id)
					AND (schedule_appointment_override.date_deleted is null))
	ORDER BY 
		event_date, start_time, end_time, qryEventCartesian.EventID, qryEventCartesian.InstanceID)
		
	select * from final_table
		where start_date_param<=final_table.event_date and final_table.event_date<=end_date_param
			and (except_rbs_event_id is null or except_rbs_event_id!=final_table.EventID)
			and (except_rbs_instance_id is null or except_rbs_instance_id!=final_table.InstanceID)
		order by final_table.event_date, final_table.start_time, final_table.end_time, final_table.EventID, final_table.InstanceID;

END
$$;


ALTER FUNCTION public.get_appointment_instances(start_date_param character varying, end_date_param character varying, except_rbs_event_id integer, except_rbs_instance_id integer) OWNER TO postgres;

--
-- Name: get_appointment_instances_by_provider_customer(character varying, character varying, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_appointment_instances_by_provider_customer(providerid character varying, customerid character varying, start_date_param character varying, end_date_param character varying, except_rbs_event_id integer, except_rbs_instance_id integer) RETURNS TABLE(provider_id character varying, customer_id character varying, eventid integer, instanceid integer, start_time time without time zone, end_time time without time zone, event_date text, description text, event_cancelled integer, exception_desc character varying, start_date date, end_date date, period_freq integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        SELECT * from get_appointment_instances(start_date_param, end_date_param, except_rbs_event_id, except_rbs_instance_id) as b
        where (CustomerId is null or b.customer_id=CustomerId) and (providerId is null or b.provider_id=providerId);
END
$$;


ALTER FUNCTION public.get_appointment_instances_by_provider_customer(providerid character varying, customerid character varying, start_date_param character varying, end_date_param character varying, except_rbs_event_id integer, except_rbs_instance_id integer) OWNER TO postgres;

--
-- Name: get_availability_instances(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_availability_instances(start_date_param character varying, end_date_param character varying) RETURNS TABLE(provider_id character varying, eventid integer, instanceid integer, start_time time without time zone, end_time time without time zone, event_date text, description text, event_cancelled integer, exception_desc character varying, start_date date, end_date date, period_freq integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
return query 
	with final_table as
	(SELECT
		distinct qryEventCartesian.provider_id,
		qryEventCartesian.EventID,
		qryEventCartesian.InstanceID,
		case
			when schedule_availability_override.event_id Is Null
			then
				qryEventCartesian.start_time
			else
				case
					when schedule_availability_override.event_cancelled=1
					then Null
					else schedule_availability_override.new_start_time
			end
		end start_time,
			case
				when schedule_availability_override.event_id Is Null
				then
					qryEventCartesian.end_time
				else
					case
						when schedule_availability_override.event_cancelled=1
						then Null
						else schedule_availability_override.new_end_time
			end
		end end_time,
		TO_CHAR(case
			when schedule_availability_override.event_id Is Null
			then
				case
					when (qryEventCartesian.period_typeid Is Null) Or (qryEventCartesian.period_freq Is Null) Or (qryEventCartesian.InstanceID Is Null)
					then qryEventCartesian.start_date
					else
						temperal_add(
							qryEventCartesian.start_date,
							qryEventCartesian.InstanceID*qryEventCartesian.period_freq,
							qryEventCartesian.period_typeid)
				end
			else
				case
					when schedule_availability_override.event_cancelled=1
					then temperal_add(
							qryEventCartesian.start_date,
							qryEventCartesian.InstanceID*qryEventCartesian.period_freq,
							qryEventCartesian.period_typeid)
					else schedule_availability_override.new_date
				end
		end, 'yyyy-mm-dd') AS event_date,
		qryEventCartesian.description,
		schedule_availability_override.event_cancelled,
		schedule_availability_override.description as exception_desc,
		qryEventCartesian.start_date,
		qryEventCartesian.end_date,
		qryEventCartesian.period_freq
	FROM (
		(SELECT
			schedule_availability.event_id AS EventID,
			tbl_instants.id AS InstanceID,
			schedule_availability.description,
			schedule_availability.start_date,
			schedule_availability.end_date,
			schedule_availability.period_freq,
			schedule_availability.start_time,
			schedule_availability.end_time,
			schedule_availability.provider_id ,
			schedule_availability.period_typeid
		FROM schedule_availability, get_instance_seed_table(100) as tbl_instants
		WHERE
			(schedule_availability.end_date IS Null OR
			schedule_availability.end_date >=temperal_add(schedule_availability.start_date, tbl_instants.id, schedule_availability.period_typeid))	 	
			and schedule_availability.is_enable=1 and schedule_availability.date_deleted is null
		ORDER BY
			schedule_availability.event_id) AS qryEventCartesian
			LEFT JOIN schedule_availability_override
				ON (qryEventCartesian.InstanceID = schedule_availability_override.instance_id)
					AND (qryEventCartesian.EventID = schedule_availability_override.event_id)
					AND (schedule_availability_override.date_deleted is null))
	ORDER BY
		event_date, start_time, end_time, qryEventCartesian.EventID, qryEventCartesian.InstanceID)
	
	select * from final_table
		where start_date_param<=final_table.event_date and final_table.event_date<=end_date_param;

END
$$;


ALTER FUNCTION public.get_availability_instances(start_date_param character varying, end_date_param character varying) OWNER TO postgres;

--
-- Name: get_availability_instances_by_provider(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_availability_instances_by_provider(providerid character varying, start_date_param character varying, end_date_param character varying) RETURNS TABLE(provider_id character varying, eventid integer, instanceid integer, start_time time without time zone, end_time time without time zone, event_date text, description text, event_cancelled integer, exception_desc character varying, start_date date, end_date date, period_freq integer)
    LANGUAGE plpgsql
    AS $$
BEGIN

return query
SELECT * from get_availability_instances(start_date_param, end_date_param) as b
where (providerID is null or b.provider_id=providerID);

END
$$;


ALTER FUNCTION public.get_availability_instances_by_provider(providerid character varying, start_date_param character varying, end_date_param character varying) OWNER TO postgres;

--
-- Name: get_instance_seed_table(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_instance_seed_table(seed_count integer) RETURNS TABLE(id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN 
CREATE TEMPORARY TABLE IF NOT EXISTS instance_seeds (id Integer);
IF (select count(*) from instance_seeds)<seed_count THEN
	for i in 0..seed_count-1 loop 
		insert into instance_seeds values (i);
	end loop;
END IF;

return query select * from instance_seeds;
END
$$;


ALTER FUNCTION public.get_instance_seed_table(seed_count integer) OWNER TO postgres;

--
-- Name: get_tmp_instances(integer, character varying, character varying, character varying, character varying, integer, character varying, integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_tmp_instances(p_instance_id integer, p_start_date character varying, p_end_date character varying, p_start_time character varying, p_end_time character varying, p_period_freq integer, p_period_typeid character varying, p_check_freq integer, p_check_freq_typeid character varying) RETURNS TABLE(eventid integer, instanceid integer, start_time time without time zone, end_time time without time zone, event_date date, start_date date, end_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN

CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rbs_event (
	event_id Integer,
	start_time time without time zone,
	end_time time without time zone,
	period_freq integer,
	period_typeid character varying,
	start_date date,
	end_date date);
delete from tmp_rbs_event;
INSERT INTO tmp_rbs_event (event_id, start_time, end_time, period_freq, period_typeid, start_date, end_date) 
values (
	p_instance_id,
	p_start_time::time without time zone, 
	p_end_time::time without time zone, 
	p_period_freq, 
	p_period_typeid, 
	p_start_date::date, 
	p_end_date::date);

return query SELECT 
	qryEventCartesian.EventID, 
	qryEventCartesian.InstanceID,
	qryEventCartesian.start_time, 
	qryEventCartesian.end_time, 
	temperal_add(
		qryEventCartesian.start_date, 
		qryEventCartesian.InstanceID*qryEventCartesian.period_freq,
		qryEventCartesian.period_typeid) AS event_date,
	qryEventCartesian.start_date, 
	qryEventCartesian.end_date
FROM (SELECT 
		distinct tbl_instants.id AS InstanceID,
		tmp_rbs_event.event_id AS EventID, 
	 	tmp_rbs_event.start_time,
	 	tmp_rbs_event.end_time,
		tmp_rbs_event.period_freq, 
		tmp_rbs_event.period_typeid,
		tmp_rbs_event.start_date, 
		tmp_rbs_event.end_date
	FROM 
		tmp_rbs_event, get_instance_seed_table(1000) as tbl_instants
	WHERE 
	  	case
	  		when tmp_rbs_event.end_date IS Null
	  		then 
	  			temperal_add(tmp_rbs_event.start_date, p_check_freq, p_check_freq_typeid)
				 >=
				 temperal_add(tmp_rbs_event.start_date, tbl_instants.id, tmp_rbs_event.period_typeid)
	  		else
	  			tmp_rbs_event.end_date >=temperal_add(tmp_rbs_event.start_date, tbl_instants.id, tmp_rbs_event.period_typeid)
	  	end
	ORDER BY 
		tmp_rbs_event.event_id) AS qryEventCartesian 
ORDER BY 
	event_date, start_time, end_time, qryEventCartesian.EventID, qryEventCartesian.InstanceID;

END
$$;


ALTER FUNCTION public.get_tmp_instances(p_instance_id integer, p_start_date character varying, p_end_date character varying, p_start_time character varying, p_end_time character varying, p_period_freq integer, p_period_typeid character varying, p_check_freq integer, p_check_freq_typeid character varying) OWNER TO postgres;

--
-- Name: is_any_availability_to_book(public.event_type, character varying, integer, integer, time without time zone, time without time zone, date, date, date, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.is_any_availability_to_book(new_event public.event_type, INOUT provider_id character varying, INOUT event_id integer, INOUT instance_id integer, INOUT start_time time without time zone, INOUT end_time time without time zone, INOUT start_date date, INOUT end_date date, INOUT event_date date, INOUT description text, INOUT exception_desc text)
    LANGUAGE plpgsql
    AS $$
declare
   overlap_instance overlap_instance_type := null;
BEGIN

	select 
		distinct a.provider_id,
		null,
		a.eventid,
		a.instanceid,
		a.start_time,
		a.end_time,
		a.start_date,
		a.end_date,
		a.event_date,
		a.description,
		a.exception_desc
	from
		get_availability_instances_by_provider(
			new_event.provider_id, 
			new_event.start_date::character varying, 
			case when new_event.end_date is null
				then temperal_add(new_event.start_date, 1, 'year')::character varying
				else new_event.end_date::character varying
			end) a
		inner join (select * from get_tmp_instances(
						66666, 
						new_event.start_date::character varying, 
						new_event.end_date::character varying, 
						new_event.start_time::character varying, 
						new_event.end_time::character varying, 
						new_event.period_freq, 
						new_event.period_typeid, 
						1, 
						'year'::character varying)) b
			on(
				a.event_date::date=b.event_date and a.event_date::date=new_event.start_date::date
				and
				((b.start_time between a.start_time and a.end_time or a.start_time=b.start_time)
				and (b.end_time between a.start_time and a.end_time or a.end_time=b.end_time)))
	order by a.event_date, a.instanceid, a.start_time
	limit 1 offset 0 into overlap_instance;	
	
	select overlap_instance.provider_id into provider_id;
	select overlap_instance.eventid into event_id;
	select overlap_instance.instanceid into instance_id;
	select overlap_instance.start_time into start_time;
	select overlap_instance.end_time into end_time;
	select overlap_instance.start_date into start_date;
	select overlap_instance.end_date into end_date;
	select overlap_instance.event_date into event_date;
	select overlap_instance.description into description;
	select overlap_instance.exception_desc into exception_desc;
	
	
END 
$$;


ALTER PROCEDURE public.is_any_availability_to_book(new_event public.event_type, INOUT provider_id character varying, INOUT event_id integer, INOUT instance_id integer, INOUT start_time time without time zone, INOUT end_time time without time zone, INOUT start_date date, INOUT end_date date, INOUT event_date date, INOUT description text, INOUT exception_desc text) OWNER TO postgres;

--
-- Name: is_overlap_with_availability_instances(public.event_type, integer, integer, character varying, integer, integer, time without time zone, time without time zone, date, date, date, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.is_overlap_with_availability_instances(new_event public.event_type, to_be_excepted_availability_event_id integer, to_be_excepted_availability_instance_id integer, INOUT provider_id character varying, INOUT event_id integer, INOUT instance_id integer, INOUT start_time time without time zone, INOUT end_time time without time zone, INOUT start_date date, INOUT end_date date, INOUT event_date date, INOUT description text, INOUT exception_desc text)
    LANGUAGE plpgsql
    AS $$
declare
   overlap_instance overlap_instance_type := null;
BEGIN

	select 
		distinct a.provider_id,
		null,
		a.eventid,
		a.instanceid,
		a.start_time,
		a.end_time,
		a.start_date,
		a.end_date,
		a.event_date,
		a.description,
		a.exception_desc
	from
		get_availability_instances_by_provider(
			new_event.provider_id, 
			new_event.start_date::character varying, 
			case when new_event.end_date is null
				then temperal_add(new_event.start_date, 1, 'year')::character varying
				else new_event.end_date::character varying
			end) a
		inner join (select * from get_tmp_instances(
						66666, 
						new_event.start_date::character varying, 
						new_event.end_date::character varying, 
						new_event.start_time::character varying, 
						new_event.end_time::character varying, 
						new_event.period_freq, 
						new_event.period_typeid, 
						1, 
						'year'::character varying)) b
			on(a.event_date::date=b.event_date
				and
				((a.start_time between b.start_time and b.end_time and a.start_time!=b.end_time)
				or (a.end_time between b.start_time and b.end_time and a.end_time!=b.start_time)) 
				and 
				(to_be_excepted_availability_event_id is null or to_be_excepted_availability_event_id!=a.eventid)
				and
				(to_be_excepted_availability_instance_id is null or to_be_excepted_availability_instance_id!=a.instanceid))
	order by a.event_date, a.instanceid, a.start_time
	limit 1 offset 0 into overlap_instance;	
	
	select overlap_instance.provider_id into provider_id;
	select overlap_instance.eventid into event_id;
	select overlap_instance.instanceid into instance_id;
	select overlap_instance.start_time into start_time;
	select overlap_instance.end_time into end_time;
	select overlap_instance.start_date into start_date;
	select overlap_instance.end_date into end_date;
	select overlap_instance.event_date into event_date;
	select overlap_instance.description into description;
	select overlap_instance.exception_desc into exception_desc;
	
	
END 
$$;


ALTER PROCEDURE public.is_overlap_with_availability_instances(new_event public.event_type, to_be_excepted_availability_event_id integer, to_be_excepted_availability_instance_id integer, INOUT provider_id character varying, INOUT event_id integer, INOUT instance_id integer, INOUT start_time time without time zone, INOUT end_time time without time zone, INOUT start_date date, INOUT end_date date, INOUT event_date date, INOUT description text, INOUT exception_desc text) OWNER TO postgres;

--
-- Name: is_overlap_with_booked_instances(public.event_type, integer, integer, character varying, character varying, integer, integer, time without time zone, time without time zone, date, date, date, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.is_overlap_with_booked_instances(new_event public.event_type, to_be_excepted_booked_event_id integer, to_be_excepted_booked_instance_id integer, INOUT provider_id character varying, INOUT customer_id character varying, INOUT event_id integer, INOUT instance_id integer, INOUT start_time time without time zone, INOUT end_time time without time zone, INOUT start_date date, INOUT end_date date, INOUT event_date date, INOUT description text, INOUT exception_desc text)
    LANGUAGE plpgsql
    AS $$
declare
   overlap_instance overlap_instance_type := null;
BEGIN

	select 
		distinct a.provider_id,
		a.customer_id,
		a.eventid,
		a.instanceid,
		a.start_time,
		a.end_time,
		a.start_date,
		a.end_date,
		a.event_date,
		a.description,
		a.exception_desc
	from
		get_appointment_instances_by_provider_customer(
			new_event.provider_id, 
			null, 
			new_event.start_date::character varying, 
			case when new_event.end_date is null
				then temperal_add(new_event.start_date, 1, 'year')::character varying
				else new_event.end_date::character varying
			end,
			to_be_excepted_booked_event_id,
			to_be_excepted_booked_instance_id) a
		inner join (select * from get_tmp_instances(
						66666, 
						new_event.start_date::character varying, 
						new_event.end_date::character varying, 
						new_event.start_time::character varying, 
						new_event.end_time::character varying, 
						new_event.period_freq, 
						new_event.period_typeid, 
						1, 
						'year'::character varying)) b
			on(
				a.event_date::date=b.event_date
				and
				((a.start_time between b.start_time and b.end_time and a.start_time!=b.end_time)
				or (a.end_time between b.start_time and b.end_time and a.end_time!=b.start_time)) 
				and 
				(to_be_excepted_booked_event_id is null or to_be_excepted_booked_event_id!=a.eventid)
				and
				(to_be_excepted_booked_instance_id is null or to_be_excepted_booked_instance_id!=a.instanceid))
	order by a.event_date, a.instanceid, a.start_time
	limit 1 offset 0 into overlap_instance;	
	
	select overlap_instance.provider_id into provider_id;
	select overlap_instance.customer_id into customer_id;
	select overlap_instance.eventid into event_id;
	select overlap_instance.instanceid into instance_id;
	select overlap_instance.start_time into start_time;
	select overlap_instance.end_time into end_time;
	select overlap_instance.start_date into start_date;
	select overlap_instance.end_date into end_date;
	select overlap_instance.event_date into event_date;
	select overlap_instance.description into description;
	select overlap_instance.exception_desc into exception_desc;
	
	
END 
$$;


ALTER PROCEDURE public.is_overlap_with_booked_instances(new_event public.event_type, to_be_excepted_booked_event_id integer, to_be_excepted_booked_instance_id integer, INOUT provider_id character varying, INOUT customer_id character varying, INOUT event_id integer, INOUT instance_id integer, INOUT start_time time without time zone, INOUT end_time time without time zone, INOUT start_date date, INOUT end_date date, INOUT event_date date, INOUT description text, INOUT exception_desc text) OWNER TO postgres;

--
-- Name: temperal_add(date, integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.temperal_add(base_date date, interval_value integer, period_type character varying) RETURNS date
    LANGUAGE sql
    AS $$
select (base_date + (interval_value || ' ' || period_type)::interval)::date 
$$;


ALTER FUNCTION public.temperal_add(base_date date, interval_value integer, period_type character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_profiles (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    phone_number character varying(20),
    share_requests integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.customer_profiles OWNER TO postgres;

--
-- Name: general_subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.general_subjects (
    id character varying(36) NOT NULL,
    subject_name character varying(100),
    description character varying(1000),
    subject_category character varying(100),
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.general_subjects OWNER TO postgres;

--
-- Name: msg_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.msg_blocks (
    id character varying(36) NOT NULL,
    conversation_id character varying(36) NOT NULL,
    user_id_blocker character varying(36) NOT NULL,
    user_id_recipient character varying(36) NOT NULL,
    block_type integer DEFAULT 0,
    blocked_by_admin boolean DEFAULT false,
    date_created timestamp(6) with time zone
);


ALTER TABLE public.msg_blocks OWNER TO postgres;

--
-- Name: COLUMN msg_blocks.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.id IS 'Unique ID of this row';


--
-- Name: COLUMN msg_blocks.conversation_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.conversation_id IS 'ID of the conversation chain between the two parties.';


--
-- Name: COLUMN msg_blocks.user_id_blocker; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.user_id_blocker IS 'User_id which is doing the blocking';


--
-- Name: COLUMN msg_blocks.user_id_recipient; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.user_id_recipient IS 'User_id which is being blocked';


--
-- Name: COLUMN msg_blocks.block_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.block_type IS '0:None 1:HideThread 2:BlockSilent 3:BlockHard';


--
-- Name: COLUMN msg_blocks.blocked_by_admin; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.blocked_by_admin IS 'True if this block was put in place by admins.  Otherwise it was done by the user_id_blocker';


--
-- Name: COLUMN msg_blocks.date_created; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_blocks.date_created IS 'Date and time when this block was put in place';


--
-- Name: msg_emails_sent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.msg_emails_sent (
    id character varying(36) NOT NULL,
    origin_from_system boolean DEFAULT false,
    origin_from_subsystem character varying(36),
    origin_from_user_id character varying(36),
    email_from character varying(1000),
    email_to character varying(1000),
    email_cc character varying(1000),
    email_bcc character varying(1000),
    subject character varying(1000),
    message character varying(5000),
    send_status integer,
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone
);


ALTER TABLE public.msg_emails_sent OWNER TO postgres;

--
-- Name: COLUMN msg_emails_sent.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.id IS 'Unique ID of this message';


--
-- Name: COLUMN msg_emails_sent.origin_from_system; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.origin_from_system IS 'True if this email was originated by the system';


--
-- Name: COLUMN msg_emails_sent.origin_from_subsystem; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.origin_from_subsystem IS 'ID of the subsystem which created this email.  Only populated if origin_from_system=TRUE';


--
-- Name: COLUMN msg_emails_sent.origin_from_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.origin_from_user_id IS 'User_id which created this email';


--
-- Name: COLUMN msg_emails_sent.email_from; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.email_from IS 'Email address which was populated in the email field: from';


--
-- Name: COLUMN msg_emails_sent.email_to; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.email_to IS 'Email address which was populated in the email field: to';


--
-- Name: COLUMN msg_emails_sent.email_cc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.email_cc IS 'Email address which was populated in the email field: cc';


--
-- Name: COLUMN msg_emails_sent.email_bcc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.email_bcc IS 'Email address which was populated in the email field: bcc';


--
-- Name: COLUMN msg_emails_sent.subject; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.subject IS 'Email address which was populated in the email field: subject';


--
-- Name: COLUMN msg_emails_sent.message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.message IS 'Email address which was populated in the email field: message';


--
-- Name: COLUMN msg_emails_sent.send_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.send_status IS '0:Pending 1:Sent 2:Failed';


--
-- Name: COLUMN msg_emails_sent.date_created; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.date_created IS 'Date and Time when this record was created';


--
-- Name: COLUMN msg_emails_sent.date_updated; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_emails_sent.date_updated IS 'Date and Time when this record was last updated';


--
-- Name: msg_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.msg_messages (
    id character varying(36) NOT NULL,
    conversation_id character varying(36) NOT NULL,
    user_id_from character varying(36) NOT NULL,
    user_id_to character varying NOT NULL,
    message character varying(10000),
    message_intent integer DEFAULT 0,
    deleted boolean DEFAULT false,
    deleted_by integer,
    moderation_status integer DEFAULT 0,
    moderation_reason character varying(100),
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    confirm integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.msg_messages OWNER TO postgres;

--
-- Name: COLUMN msg_messages.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.id IS 'Unique ID of the message';


--
-- Name: COLUMN msg_messages.conversation_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.conversation_id IS 'ID of the conversation chain between the two parties.';


--
-- Name: COLUMN msg_messages.user_id_from; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.user_id_from IS 'User_id who sent the message';


--
-- Name: COLUMN msg_messages.user_id_to; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.user_id_to IS 'User_id who received the message';


--
-- Name: COLUMN msg_messages.message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.message IS 'Message body';


--
-- Name: COLUMN msg_messages.message_intent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.message_intent IS '0:Normal 1:ProviderSolicitingClass 2:CustInitiated 3:CustProposingAppt 4:ProviderAcceptingAppt 5:ProviderRejectingAppt 6:ProviderMsgReAppt 7:SchedulingOther 8:ProviderNoInterest';


--
-- Name: COLUMN msg_messages.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.deleted IS 'True if this message was deleted';


--
-- Name: COLUMN msg_messages.deleted_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.deleted_by IS '0:Sender 1:System 2:Recipient';


--
-- Name: COLUMN msg_messages.moderation_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.moderation_status IS '0:OK 1:PendingReview 2:Blocked';


--
-- Name: COLUMN msg_messages.moderation_reason; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.moderation_reason IS 'Reason why this message was flagged for moderation';


--
-- Name: COLUMN msg_messages.date_created; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.date_created IS 'Date and Time when this row was created';


--
-- Name: COLUMN msg_messages.date_updated; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.date_updated IS 'Date and Time when this row was last updated';


--
-- Name: COLUMN msg_messages.confirm; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.msg_messages.confirm IS '0: unread, 1: read';


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    user_id_reviewer character varying(36),
    session_id character varying(36),
    rating smallint,
    date_created timestamp with time zone,
    review_text text,
    pending_approval smallint,
    deleted smallint DEFAULT 0,
    featured smallint DEFAULT 0,
    date_updated timestamp with time zone
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: schedule_appointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_appointment (
    event_id integer NOT NULL,
    customer_id character varying(36) NOT NULL,
    start_time time(6) without time zone NOT NULL,
    end_time time(6) without time zone NOT NULL,
    time_zone character varying DEFAULT 'UTC'::character varying,
    period_freq integer,
    period_typeid character varying(7),
    start_date date,
    end_date date,
    description text,
    is_enable integer DEFAULT 1 NOT NULL,
    provider_id character varying,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone
);


ALTER TABLE public.schedule_appointment OWNER TO postgres;

--
-- Name: schedule_appointment_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.schedule_appointment ALTER COLUMN event_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.schedule_appointment_event_id_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: schedule_appointment_override; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_appointment_override (
    id integer NOT NULL,
    event_id integer NOT NULL,
    instance_id integer NOT NULL,
    event_cancelled integer,
    new_start_time time(6) without time zone,
    new_end_time time(6) without time zone,
    new_date date,
    description character varying,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone
);


ALTER TABLE public.schedule_appointment_override OWNER TO postgres;

--
-- Name: schedule_appointment_override_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.schedule_appointment_override ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.schedule_appointment_override_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: schedule_availability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_availability (
    event_id integer NOT NULL,
    provider_id character varying(36) NOT NULL,
    start_time time(6) without time zone NOT NULL,
    end_time time(6) without time zone NOT NULL,
    time_zone character varying DEFAULT 'UTC'::character varying,
    period_freq integer,
    period_typeid character varying(7),
    start_date date,
    end_date date,
    description text,
    is_enable integer DEFAULT 1 NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone
);


ALTER TABLE public.schedule_availability OWNER TO postgres;

--
-- Name: schedule_availability_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.schedule_availability ALTER COLUMN event_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.schedule_availability_event_id_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: schedule_availability_override; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_availability_override (
    id integer NOT NULL,
    event_id integer NOT NULL,
    instance_id integer NOT NULL,
    event_cancelled integer,
    new_start_time time(6) without time zone,
    new_end_time time(6) without time zone,
    new_date date,
    description character varying,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    date_deleted timestamp with time zone
);


ALTER TABLE public.schedule_availability_override OWNER TO postgres;

--
-- Name: schedule_availability_override_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.schedule_availability_override ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.schedule_availability_override_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    start_date_time timestamp(6) with time zone,
    end_date_time timestamp(6) with time zone,
    online boolean DEFAULT true,
    location character varying(100),
    provider_user_id character varying(36) NOT NULL,
    provider_first_name character varying(30),
    provider_last_name character varying(30),
    schedule_appointment_id character varying(36),
    session_in_past boolean DEFAULT false,
    session_cancelled smallint DEFAULT 0,
    provider_notes character varying(1000),
    customer_feedback character varying(1000),
    customer_feedback_public boolean DEFAULT false,
    customer_rating integer,
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    updated_by_user_id character varying,
    deleted boolean DEFAULT false
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: COLUMN sessions.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.id IS 'Unique SessionID';


--
-- Name: COLUMN sessions.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.user_id IS 'Customer user_id';


--
-- Name: COLUMN sessions.start_date_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.start_date_time IS 'Start Date and Time of this session';


--
-- Name: COLUMN sessions.end_date_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.end_date_time IS 'End Date and Time of this session';


--
-- Name: COLUMN sessions.online; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.online IS 'True if this session is an Online Session';


--
-- Name: COLUMN sessions.location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.location IS 'Location if this is not an online session';


--
-- Name: COLUMN sessions.provider_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.provider_user_id IS 'User_id of the provider of the service';


--
-- Name: COLUMN sessions.provider_first_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.provider_first_name IS 'First Name of the provider of the service';


--
-- Name: COLUMN sessions.provider_last_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.provider_last_name IS 'Last Name of the provider of the service';


--
-- Name: COLUMN sessions.schedule_appointment_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.schedule_appointment_id IS 'ID of the record in the schedule_appointment table which resulted in this session';


--
-- Name: COLUMN sessions.session_in_past; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.session_in_past IS 'True if this session was already in the past and not in the future';


--
-- Name: COLUMN sessions.session_cancelled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.session_cancelled IS '0:NotCancelled 1:CancelledByCustomer 2:CancelledByProvider 3:CancelledByAdmin';


--
-- Name: COLUMN sessions.provider_notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.provider_notes IS 'Session notes, written by the service provider';


--
-- Name: COLUMN sessions.customer_feedback; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.customer_feedback IS 'Customer feedback regarding the session';


--
-- Name: COLUMN sessions.customer_feedback_public; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.customer_feedback_public IS 'True if Customer is leaving a public feedback or review';


--
-- Name: COLUMN sessions.customer_rating; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.customer_rating IS 'Customer provided rating of this session';


--
-- Name: COLUMN sessions.date_created; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.date_created IS 'Date and time of when this session was initially created';


--
-- Name: COLUMN sessions.date_updated; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.date_updated IS 'Date and time when this record was last updated';


--
-- Name: COLUMN sessions.updated_by_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.updated_by_user_id IS 'User_id who last updated this record.  Null if it was updated by system ';


--
-- Name: COLUMN sessions.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sessions.deleted IS 'True if record has been deleted';


--
-- Name: tutor_application; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_application (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    education text,
    experience text,
    phone_number character varying(20),
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.tutor_application OWNER TO postgres;

--
-- Name: tutor_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_profiles (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    bio text,
    age integer,
    hourly_rate integer,
    cancelation_hours integer,
    student_level character varying(200),
    avatar_url character varying(120),
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    headline character varying(30),
    gender character varying(1),
    phone_number character varying(20),
    approved smallint DEFAULT 0
);


ALTER TABLE public.tutor_profiles OWNER TO postgres;

--
-- Name: COLUMN tutor_profiles.gender; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tutor_profiles.gender IS 'M:Male  F:Female  O:Other  U:Unknown';


--
-- Name: COLUMN tutor_profiles.approved; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tutor_profiles.approved IS '0:Pending  1:Approved  2:Rejected  3:Error';


--
-- Name: tutor_qualifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_qualifications (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    qualification character varying(200),
    type smallint,
    pos smallint,
    start_year integer,
    end_year integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.tutor_qualifications OWNER TO postgres;

--
-- Name: COLUMN tutor_qualifications.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tutor_qualifications.type IS '0:Education 1:Certification 2:Experience';


--
-- Name: COLUMN tutor_qualifications.pos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tutor_qualifications.pos IS 'Order to display - 0,1,2,3,4 etc';


--
-- Name: tutor_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_stats (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    response_time_minutes integer,
    ratings_total integer,
    ratings_average double precision,
    availability character varying(7),
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.tutor_stats OWNER TO postgres;

--
-- Name: tutor_subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_subjects (
    user_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    subject_id character varying(36),
    date_created timestamp with time zone,
    date_updated timestamp with time zone
);


ALTER TABLE public.tutor_subjects OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    email character varying(255) NOT NULL,
    password character varying(255),
    type integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    id character varying(36) NOT NULL,
    from_google integer,
    last_login_date timestamp with time zone,
    is_delete integer DEFAULT 0,
    disabled_by character varying(255),
    deleted_by character varying(255),
    disabled integer DEFAULT 0,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    first_name character varying(30),
    last_name character varying(30),
    time_zone character varying(30)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.type IS '0: super admin
1: admin
2: parent
3: tutor';


--
-- Name: COLUMN users.last_login_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.last_login_date IS 'last Login Date';


--
-- Name: COLUMN users.is_delete; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.is_delete IS '0: no, 1: yes';


--
-- Name: COLUMN users.disabled_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.disabled_by IS 'email address who disable the user';


--
-- Name: COLUMN users.deleted_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.deleted_by IS 'email address who delete the user';


--
-- Name: COLUMN users.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.disabled IS '0: no, 1: yes';


--
-- Name: verification_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_token (
    token character varying(255) NOT NULL,
    expiry_date timestamp without time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE public.verification_token OWNER TO postgres;

--
-- Data for Name: pga_jobagent; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_jobagent (jagpid, jaglogintime, jagstation) FROM stdin;
\.
COPY pgagent.pga_jobagent (jagpid, jaglogintime, jagstation) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: pga_jobclass; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_jobclass (jclid, jclname) FROM stdin;
\.
COPY pgagent.pga_jobclass (jclid, jclname) FROM '$$PATH$$/3125.dat';

--
-- Data for Name: pga_job; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_job (jobid, jobjclid, jobname, jobdesc, jobhostagent, jobenabled, jobcreated, jobchanged, jobagentid, jobnextrun, joblastrun) FROM stdin;
\.
COPY pgagent.pga_job (jobid, jobjclid, jobname, jobdesc, jobhostagent, jobenabled, jobcreated, jobchanged, jobagentid, jobnextrun, joblastrun) FROM '$$PATH$$/3126.dat';

--
-- Data for Name: pga_schedule; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_schedule (jscid, jscjobid, jscname, jscdesc, jscenabled, jscstart, jscend, jscminutes, jschours, jscweekdays, jscmonthdays, jscmonths) FROM stdin;
\.
COPY pgagent.pga_schedule (jscid, jscjobid, jscname, jscdesc, jscenabled, jscstart, jscend, jscminutes, jschours, jscweekdays, jscmonthdays, jscmonths) FROM '$$PATH$$/3128.dat';

--
-- Data for Name: pga_exception; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_exception (jexid, jexscid, jexdate, jextime) FROM stdin;
\.
COPY pgagent.pga_exception (jexid, jexscid, jexdate, jextime) FROM '$$PATH$$/3129.dat';

--
-- Data for Name: pga_joblog; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_joblog (jlgid, jlgjobid, jlgstatus, jlgstart, jlgduration) FROM stdin;
\.
COPY pgagent.pga_joblog (jlgid, jlgjobid, jlgstatus, jlgstart, jlgduration) FROM '$$PATH$$/3130.dat';

--
-- Data for Name: pga_jobstep; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_jobstep (jstid, jstjobid, jstname, jstdesc, jstenabled, jstkind, jstcode, jstconnstr, jstdbname, jstonerror, jscnextrun) FROM stdin;
\.
COPY pgagent.pga_jobstep (jstid, jstjobid, jstname, jstdesc, jstenabled, jstkind, jstcode, jstconnstr, jstdbname, jstonerror, jscnextrun) FROM '$$PATH$$/3127.dat';

--
-- Data for Name: pga_jobsteplog; Type: TABLE DATA; Schema: pgagent; Owner: postgres
--

COPY pgagent.pga_jobsteplog (jslid, jsljlgid, jsljstid, jslstatus, jslresult, jslstart, jslduration, jsloutput) FROM stdin;
\.
COPY pgagent.pga_jobsteplog (jslid, jsljlgid, jsljstid, jslstatus, jslresult, jslstart, jslduration, jsloutput) FROM '$$PATH$$/3131.dat';

--
-- Data for Name: customer_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_profiles (id, user_id, phone_number, share_requests, date_created, date_updated) FROM stdin;
\.
COPY public.customer_profiles (id, user_id, phone_number, share_requests, date_created, date_updated) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: general_subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.general_subjects (id, subject_name, description, subject_category, date_created, date_updated) FROM stdin;
\.
COPY public.general_subjects (id, subject_name, description, subject_category, date_created, date_updated) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: msg_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.msg_blocks (id, conversation_id, user_id_blocker, user_id_recipient, block_type, blocked_by_admin, date_created) FROM stdin;
\.
COPY public.msg_blocks (id, conversation_id, user_id_blocker, user_id_recipient, block_type, blocked_by_admin, date_created) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: msg_emails_sent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.msg_emails_sent (id, origin_from_system, origin_from_subsystem, origin_from_user_id, email_from, email_to, email_cc, email_bcc, subject, message, send_status, date_created, date_updated) FROM stdin;
\.
COPY public.msg_emails_sent (id, origin_from_system, origin_from_subsystem, origin_from_user_id, email_from, email_to, email_cc, email_bcc, subject, message, send_status, date_created, date_updated) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: msg_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.msg_messages (id, conversation_id, user_id_from, user_id_to, message, message_intent, deleted, deleted_by, moderation_status, moderation_reason, date_created, date_updated, confirm) FROM stdin;
\.
COPY public.msg_messages (id, conversation_id, user_id_from, user_id_to, message, message_intent, deleted, deleted_by, moderation_status, moderation_reason, date_created, date_updated, confirm) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, user_id, user_id_reviewer, session_id, rating, date_created, review_text, pending_approval, deleted, featured, date_updated) FROM stdin;
\.
COPY public.reviews (id, user_id, user_id_reviewer, session_id, rating, date_created, review_text, pending_approval, deleted, featured, date_updated) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: schedule_appointment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_appointment (event_id, customer_id, start_time, end_time, time_zone, period_freq, period_typeid, start_date, end_date, description, is_enable, provider_id, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.schedule_appointment (event_id, customer_id, start_time, end_time, time_zone, period_freq, period_typeid, start_date, end_date, description, is_enable, provider_id, date_created, date_updated, date_deleted) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: schedule_appointment_override; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_appointment_override (id, event_id, instance_id, event_cancelled, new_start_time, new_end_time, new_date, description, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.schedule_appointment_override (id, event_id, instance_id, event_cancelled, new_start_time, new_end_time, new_date, description, date_created, date_updated, date_deleted) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: schedule_availability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_availability (event_id, provider_id, start_time, end_time, time_zone, period_freq, period_typeid, start_date, end_date, description, is_enable, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.schedule_availability (event_id, provider_id, start_time, end_time, time_zone, period_freq, period_typeid, start_date, end_date, description, is_enable, date_created, date_updated, date_deleted) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: schedule_availability_override; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_availability_override (id, event_id, instance_id, event_cancelled, new_start_time, new_end_time, new_date, description, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.schedule_availability_override (id, event_id, instance_id, event_cancelled, new_start_time, new_end_time, new_date, description, date_created, date_updated, date_deleted) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, start_date_time, end_date_time, online, location, provider_user_id, provider_first_name, provider_last_name, schedule_appointment_id, session_in_past, session_cancelled, provider_notes, customer_feedback, customer_feedback_public, customer_rating, date_created, date_updated, updated_by_user_id, deleted) FROM stdin;
\.
COPY public.sessions (id, user_id, start_date_time, end_date_time, online, location, provider_user_id, provider_first_name, provider_last_name, schedule_appointment_id, session_in_past, session_cancelled, provider_notes, customer_feedback, customer_feedback_public, customer_rating, date_created, date_updated, updated_by_user_id, deleted) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: tutor_application; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_application (id, user_id, education, experience, phone_number, date_created, date_updated) FROM stdin;
\.
COPY public.tutor_application (id, user_id, education, experience, phone_number, date_created, date_updated) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: tutor_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_profiles (id, user_id, bio, age, hourly_rate, cancelation_hours, student_level, avatar_url, date_created, date_updated, headline, gender, phone_number, approved) FROM stdin;
\.
COPY public.tutor_profiles (id, user_id, bio, age, hourly_rate, cancelation_hours, student_level, avatar_url, date_created, date_updated, headline, gender, phone_number, approved) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: tutor_qualifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_qualifications (id, user_id, qualification, type, pos, start_year, end_year, date_created, date_updated) FROM stdin;
\.
COPY public.tutor_qualifications (id, user_id, qualification, type, pos, start_year, end_year, date_created, date_updated) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: tutor_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_stats (id, user_id, response_time_minutes, ratings_total, ratings_average, availability, date_created, date_updated) FROM stdin;
\.
COPY public.tutor_stats (id, user_id, response_time_minutes, ratings_total, ratings_average, availability, date_created, date_updated) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: tutor_subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_subjects (user_id, id, subject_id, date_created, date_updated) FROM stdin;
\.
COPY public.tutor_subjects (user_id, id, subject_id, date_created, date_updated) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (email, password, type, enabled, id, from_google, last_login_date, is_delete, disabled_by, deleted_by, disabled, date_created, date_updated, first_name, last_name, time_zone) FROM stdin;
\.
COPY public.users (email, password, type, enabled, id, from_google, last_login_date, is_delete, disabled_by, deleted_by, disabled, date_created, date_updated, first_name, last_name, time_zone) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: verification_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_token (token, expiry_date, user_id, id) FROM stdin;
\.
COPY public.verification_token (token, expiry_date, user_id, id) FROM '$$PATH$$/3381.dat';

--
-- Name: schedule_appointment_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_appointment_event_id_seq', 82, true);


--
-- Name: schedule_appointment_override_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_appointment_override_id_seq', 8, true);


--
-- Name: schedule_availability_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_availability_event_id_seq', 23, true);


--
-- Name: schedule_availability_override_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_availability_override_id_seq', 23, true);


--
-- Name: customer_profiles customer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_pkey PRIMARY KEY (id);


--
-- Name: general_subjects general_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.general_subjects
    ADD CONSTRAINT general_subject_pkey PRIMARY KEY (id);


--
-- Name: msg_blocks msg_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.msg_blocks
    ADD CONSTRAINT msg_blocks_pkey PRIMARY KEY (id);


--
-- Name: msg_messages msg_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.msg_messages
    ADD CONSTRAINT msg_messages_pkey PRIMARY KEY (id);


--
-- Name: schedule_appointment_override n_schedule_appointment_override_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_appointment_override
    ADD CONSTRAINT n_schedule_appointment_override_pkey PRIMARY KEY (id);


--
-- Name: schedule_appointment n_schedule_appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_appointment
    ADD CONSTRAINT n_schedule_appointment_pkey PRIMARY KEY (event_id);


--
-- Name: schedule_availability_override n_schedule_availability_override_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_availability_override
    ADD CONSTRAINT n_schedule_availability_override_pkey PRIMARY KEY (id);


--
-- Name: schedule_availability n_schedule_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_availability
    ADD CONSTRAINT n_schedule_availability_pkey PRIMARY KEY (event_id);


--
-- Name: reviews review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: tutor_application tutor_application_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_application
    ADD CONSTRAINT tutor_application_pkey PRIMARY KEY (id);


--
-- Name: tutor_profiles tutor_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_profiles
    ADD CONSTRAINT tutor_profile_pkey PRIMARY KEY (id);


--
-- Name: tutor_qualifications tutor_qualification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_qualifications
    ADD CONSTRAINT tutor_qualification_pkey PRIMARY KEY (id);


--
-- Name: tutor_stats tutor_stat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_stats
    ADD CONSTRAINT tutor_stat_pkey PRIMARY KEY (id);


--
-- Name: tutor_subjects tutors_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_subjects
    ADD CONSTRAINT tutors_subjects_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_token verification_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_pkey PRIMARY KEY (id);


--
-- Name: verification_token verification_token_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_users_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

