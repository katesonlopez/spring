package org.example.task1.hidden;

import org.example.task1.visible.AppConstants;
import org.example.task1.visible.Order;
import org.example.task1.visible.OrderItem;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class OrderServiceTest {
    @Test
    public void testCalculateDiscount_NoDiscount() {
        List<OrderItem> orderItems = new ArrayList<>();
        Order order = new Order(orderItems);
        OrderService orderService = new OrderService();
        Integer discount = orderService.calculateDiscount(order);
        Assert.assertEquals(AppConstants.NO_DISCOUNT, discount);
    }

    @Test
    public void testCalculateDiscount_RegularDiscount() {
        List<OrderItem> orderItems = new ArrayList<>();
        orderItems.add(new OrderItem(1, "Product 1", List.of(AppConstants.REGULAR_DISCOUNT_TAG)));
        Order order = new Order(orderItems);
        OrderService orderService = new OrderService();
        Integer discount = orderService.calculateDiscount(order);
        Assert.assertEquals(AppConstants.REGULAR_DISCOUNT, discount);
    }

    @Test
    public void testCalculateDiscount_ExtraRareCoupon() {
        List<OrderItem> orderItems = new ArrayList<>();
        orderItems.add(new OrderItem(1, "Product 1", List.of(AppConstants.EXTRA_RARE_COUPON)));
        Order order = new Order(orderItems);
        OrderService orderService = new OrderService();
        Integer discount = orderService.calculateDiscount(order);
        Assert.assertEquals(AppConstants.HIGH_DISCOUNT, discount);
    }

    @Test
    public void testCalculateDiscount_BothDiscountTags() {
        List<OrderItem> orderItems = new ArrayList<>();
        orderItems.add(new OrderItem(1, "Product 1", List.of(AppConstants.REGULAR_DISCOUNT_TAG, AppConstants.EXTRA_RARE_COUPON)));
        Order order = new Order(orderItems);
        OrderService orderService = new OrderService();
        Integer discount = orderService.calculateDiscount(order);
        Assert.assertEquals(AppConstants.EXTRA_DISCOUNT, discount);
    }
}
