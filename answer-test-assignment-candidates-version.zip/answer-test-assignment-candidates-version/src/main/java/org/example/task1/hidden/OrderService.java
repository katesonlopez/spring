package org.example.task1.hidden;

import org.example.task1.visible.AppConstants;
import org.example.task1.visible.Order;
import org.example.task1.visible.OrderItem;
import org.example.task1.visible.OrderServiceInterface;

import java.util.List;

public class OrderService implements OrderServiceInterface {
    @Override
    public Integer calculateDiscount(Order orders) {
        //TODO: Implement me please
        List<OrderItem> orderItems = orders.getOrderItems();

        boolean regularDiscountTagPresent = false;
        boolean extraRareCouponTagPresent = false;

        for (OrderItem item : orderItems) {
            List<String> tags = item.getTags();

            if (tags.contains(AppConstants.REGULAR_DISCOUNT_TAG)) {
                regularDiscountTagPresent = true;
            }

            if (tags.contains(AppConstants.EXTRA_RARE_COUPON)) {
                extraRareCouponTagPresent = true;
            }

            if (regularDiscountTagPresent && extraRareCouponTagPresent) {
                return AppConstants.EXTRA_DISCOUNT;
            }
        }

        if (regularDiscountTagPresent) {
            return AppConstants.REGULAR_DISCOUNT;
        } else if (extraRareCouponTagPresent) {
            return AppConstants.HIGH_DISCOUNT;
        }

        return AppConstants.NO_DISCOUNT;
    }
}
