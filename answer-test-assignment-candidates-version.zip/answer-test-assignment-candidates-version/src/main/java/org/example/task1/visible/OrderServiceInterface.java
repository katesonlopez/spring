package org.example.task1.visible;


public interface OrderServiceInterface {

    /**
     * Task definition: there is a need to implement an service that calculate a possible discount for 
     * e-commerce store. The rules are following: order this is an order that customer might create on store. Order
     * might have a many order items(aka things that imagenery customer would like to buy in our store). Each orderItem
     * might be have a multiple tags. The goal is to walk through all order items and figure out the amount of discount 
     * that might be offered to user according to the following rules:
     *  - if order item contains a tag 'REGULAR_DISCOUNT': - 5%
     *  - if order item contains a tag 'EXTRA_RARE_COUPON': - 7%
     *  - if order item contains both tags: 'REGULAR_DISCOUNT' and 'EXTRA_RARE_COUPON' : 10%
     *  - in all other cases application should return NO_DISCOUNT_CODE = -1
     *  So, wrapping up: discount will be given to the whole order, if there is at least one order item with
     *  the tags specified above. In order to get maximum discount of 10% , the discount tags might be found 
     *  in scope of single order item or the might be combined from two separate order items
     *  
     *  Service should be named OrderService
     * 
     */
    Integer calculateDiscount(Order orders);
}
