package org.example.task1.visible;

import java.util.List;

public class OrderItem {

    private final Integer productId;
    
    private final String name;

    private final List<String> tags;

    public OrderItem(Integer productId, String name, List<String> tags) {
        this.productId = productId;
        this.name = name;
        this.tags = tags;
    }

    public String getName() {
        return name;
    }

    public List<String> getTags() {
        return tags;
    }

    public Integer getProductId() {
        return productId;
    }
}
