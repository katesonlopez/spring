package org.example.task1.visible;

public class AppConstants {
    
    public static String DISCOUNT_COUPON = "DISCOUNT_OF_THE_DAY"; 
     
    public static String EXTRA_RARE_COUPON = "EXTRA_RARE_COUPON";
    public static String REGULAR_DISCOUNT_TAG = "REGULAR_DISCOUNT";

    public static Integer NO_DISCOUNT = -1;
    public static Integer REGULAR_DISCOUNT = 5;
    public static Integer HIGH_DISCOUNT = 7;
    public static Integer EXTRA_DISCOUNT = 10;
}
