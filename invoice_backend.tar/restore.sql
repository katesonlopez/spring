--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE invoicedev;
--
-- Name: invoicedev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE invoicedev WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE invoicedev OWNER TO postgres;

\connect invoicedev

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.contacts (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    organization_id character varying(36),
    name character varying(100),
    email character varying(255),
    job_title character varying(50),
    phone_number character varying(30),
    address character varying(255),
    notes character varying(1000),
    primary_contact boolean,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone
);


ALTER TABLE public.contacts OWNER TO postgres_backend;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.customers (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    name character varying(100),
    industry character varying(50),
    phone_number character varying(30),
    website character varying(255),
    address character varying(255),
    notes character varying(1000),
    email character varying(255),
    currency character varying(3),
    account_number character varying(255),
    ship_to_name character varying(100),
    ship_to_address character varying(255),
    ship_to_phone character varying(30),
    ship_to_instructions character varying(255),
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone,
    archived boolean DEFAULT false,
    record_type character varying(10) DEFAULT 'Customer'::character varying
);


ALTER TABLE public.customers OWNER TO postgres_backend;

--
-- Name: COLUMN customers.record_type; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.customers.record_type IS 'Values are "Customer" or "Prospect"';


--
-- Name: invoice_footer; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.invoice_footer (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    invoice_footer_def_id character varying(36) NOT NULL,
    invoices_id character varying(36) NOT NULL,
    footer_order boolean
);


ALTER TABLE public.invoice_footer OWNER TO postgres_backend;

--
-- Name: invoice_footer_def; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.invoice_footer_def (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    footer_label character varying(100),
    footer_description character varying(500),
    archived boolean
);


ALTER TABLE public.invoice_footer_def OWNER TO postgres_backend;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.invoice_items (
    id character varying(36) NOT NULL,
    invoices_id character varying(36),
    user_id character varying(36),
    item_name character varying(50),
    item_description character varying(200),
    qty double precision,
    unit_price double precision,
    amount double precision,
    product_id character varying(36),
    "position" smallint
);


ALTER TABLE public.invoice_items OWNER TO postgres_backend;

--
-- Name: invoice_tax; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.invoice_tax (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    invoice_tax_def_id character varying(36),
    invoices_id character varying(36),
    invoice_items_id character varying(36),
    tax_order integer
);


ALTER TABLE public.invoice_tax OWNER TO postgres_backend;

--
-- Name: invoice_tax_def; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.invoice_tax_def (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    tax_name character varying(36),
    tax_percent double precision,
    compound boolean,
    recoverable boolean,
    archived boolean
);


ALTER TABLE public.invoice_tax_def OWNER TO postgres_backend;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.invoices (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    invoice_number character varying(50),
    po_number character varying(50),
    invoice_date timestamp with time zone,
    payment_due_date timestamp with time zone,
    inv_from character varying(255),
    inv_to character varying(255),
    ship_to character varying(255),
    logo character varying(50),
    currency character varying(3),
    footer_label character varying(50),
    footer_description character varying(500),
    footerhidden boolean,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone,
    signature character varying(50),
    saved boolean,
    type character varying(50),
    customer_id character varying(36),
    project_id character varying(36),
    record_type integer DEFAULT 0,
    parent_invoice_id character varying(36),
    status integer DEFAULT 0
);


ALTER TABLE public.invoices OWNER TO postgres_backend;

--
-- Name: COLUMN invoices.record_type; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.invoices.record_type IS '0=Invoice 1=Quote 2=Receipt';


--
-- Name: COLUMN invoices.parent_invoice_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.invoices.parent_invoice_id IS 'This invoice record may be related to another invoice record.  For example an Invoice may be related to a Quote, and a Payment may be related to an Invoice';


--
-- Name: COLUMN invoices.status; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.invoices.status IS '0=Draft 1=Unsent 2=Sent 3=Viewed 4=Accepted 5=Declined 6=Partial 7=Paid 8=Overdue';


--
-- Name: msg_emails_sent; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.msg_emails_sent (
    id character varying(36) NOT NULL,
    origin_from_system boolean DEFAULT false,
    origin_from_subsystem character varying(50),
    origin_from_user_id character varying(36),
    email_from character varying(1000),
    email_to character varying(1000),
    email_cc character varying(1000),
    email_bcc character varying(1000),
    subject character varying(1000),
    message character varying(5000),
    send_status integer,
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    invoice_id character varying(36),
    dtype integer DEFAULT 1
);


ALTER TABLE public.msg_emails_sent OWNER TO postgres_backend;

--
-- Name: COLUMN msg_emails_sent.id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.id IS 'Unique ID of this message';


--
-- Name: COLUMN msg_emails_sent.origin_from_system; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.origin_from_system IS 'True if this email was originated by the system';


--
-- Name: COLUMN msg_emails_sent.origin_from_subsystem; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.origin_from_subsystem IS 'ID of the subsystem which created this email.  Only populated if origin_from_system=TRUE';


--
-- Name: COLUMN msg_emails_sent.origin_from_user_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.origin_from_user_id IS 'User_id which created this email';


--
-- Name: COLUMN msg_emails_sent.email_from; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.email_from IS 'Email address which was populated in the email field: from';


--
-- Name: COLUMN msg_emails_sent.email_to; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.email_to IS 'Email address which was populated in the email field: to';


--
-- Name: COLUMN msg_emails_sent.email_cc; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.email_cc IS 'Email address which was populated in the email field: cc';


--
-- Name: COLUMN msg_emails_sent.email_bcc; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.email_bcc IS 'Email address which was populated in the email field: bcc';


--
-- Name: COLUMN msg_emails_sent.subject; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.subject IS 'Email address which was populated in the email field: subject';


--
-- Name: COLUMN msg_emails_sent.message; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.message IS 'Email address which was populated in the email field: message';


--
-- Name: COLUMN msg_emails_sent.send_status; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.send_status IS '0:Pending 1:Sent 2:Failed';


--
-- Name: COLUMN msg_emails_sent.date_created; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.date_created IS 'Date and Time when this record was created';


--
-- Name: COLUMN msg_emails_sent.date_updated; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.msg_emails_sent.date_updated IS 'Date and Time when this record was last updated';


--
-- Name: notes; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.notes (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    note_object_type integer,
    note_object_id character varying(36),
    description character varying(10000),
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone
);


ALTER TABLE public.notes OWNER TO postgres_backend;

--
-- Name: COLUMN notes.note_object_type; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.notes.note_object_type IS '0=Customer 1=Contact 2=Project 3=Task';


--
-- Name: COLUMN notes.note_object_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.notes.note_object_id IS 'This is the ID of the Customer or Contact or Project for which this is the note';


--
-- Name: payment_events; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payment_events (
    id integer NOT NULL,
    transaction_id character varying NOT NULL,
    event_type character varying NOT NULL,
    date_created timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.payment_events OWNER TO postgres_backend;

--
-- Name: TABLE payment_events; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON TABLE public.payment_events IS 'use this as a history of all received events from stripe';


--
-- Name: payment_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres_backend
--

ALTER TABLE public.payment_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payment_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    payment_method_id character varying NOT NULL,
    stripe_customer_id character varying,
    status character varying NOT NULL,
    date_created timestamp(6) with time zone NOT NULL,
    date_updated timestamp(6) with time zone NOT NULL,
    date_deleted timestamp(6) with time zone
);


ALTER TABLE public.payment_methods OWNER TO postgres_backend;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres_backend
--

ALTER TABLE public.payment_methods ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payment_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payment_prices; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payment_prices (
    id character varying(36) NOT NULL,
    price_id character varying(36),
    active boolean,
    currency character varying(36),
    product_id character varying(36),
    "interval" integer,
    interval_count integer,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone,
    amount numeric(10,2) DEFAULT 0
);


ALTER TABLE public.payment_prices OWNER TO postgres_backend;

--
-- Name: payment_products; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payment_products (
    id character varying(36) NOT NULL,
    product_id character varying(36),
    name character varying(100),
    description character varying(500),
    active boolean,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone
);


ALTER TABLE public.payment_products OWNER TO postgres_backend;

--
-- Name: payments_clients; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payments_clients (
    stripe_customer_id character varying NOT NULL,
    user_id character varying(36) NOT NULL,
    date_created time(6) with time zone,
    date_updated time(6) with time zone,
    date_deleted time(6) with time zone
);


ALTER TABLE public.payments_clients OWNER TO postgres_backend;

--
-- Name: payments_providers_accounts; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payments_providers_accounts (
    stripe_account_id character varying NOT NULL,
    user_id character varying(36),
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    date_deleted timestamp(6) with time zone,
    bank_account_id character varying,
    active_status character varying,
    person_id character varying,
    payout_status boolean
);


ALTER TABLE public.payments_providers_accounts OWNER TO postgres_backend;

--
-- Name: COLUMN payments_providers_accounts.stripe_account_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_providers_accounts.stripe_account_id IS 'the id of the stripe custom account';


--
-- Name: COLUMN payments_providers_accounts.user_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_providers_accounts.user_id IS 'our user_id of the provider';


--
-- Name: COLUMN payments_providers_accounts.bank_account_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_providers_accounts.bank_account_id IS 'provider''s bank account id created in stripe';


--
-- Name: COLUMN payments_providers_accounts.active_status; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_providers_accounts.active_status IS 'This field means the status of transfer and card payment capabilities are enabled. The possible values are "inactive", "active", "pending"...';


--
-- Name: COLUMN payments_providers_accounts.person_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_providers_accounts.person_id IS 'Id of person object that related with this account';


--
-- Name: payments_trans_payments; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.payments_trans_payments (
    id character varying NOT NULL,
    provider_id character varying(36),
    customer_id character varying(36),
    stripe_customer_id character varying,
    stripe_provider_connected_account_id character varying,
    payment_method_id character varying,
    amount numeric(10,2) DEFAULT 0,
    currency character varying(3),
    base_amount numeric(10,2) DEFAULT 0,
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    payment_intent_id character varying,
    stripe_fee numeric(10,2) DEFAULT 0,
    status character varying,
    available_on timestamp(6) with time zone,
    type character varying,
    net numeric(10,2) DEFAULT 0,
    source character varying,
    session_id character varying,
    result character varying,
    fail_reason character varying,
    fail_type character varying,
    customer_fee numeric(10,2) DEFAULT 0,
    provider_fee numeric(10,2) DEFAULT 0,
    provider_amount numeric(10,2) DEFAULT 0
);


ALTER TABLE public.payments_trans_payments OWNER TO postgres_backend;

--
-- Name: COLUMN payments_trans_payments.id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.id IS 'the transaction id';


--
-- Name: COLUMN payments_trans_payments.provider_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.provider_id IS 'user_id of the tutor in sada';


--
-- Name: COLUMN payments_trans_payments.customer_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.customer_id IS 'user_id of the customer in sada';


--
-- Name: COLUMN payments_trans_payments.stripe_customer_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.stripe_customer_id IS 'customer_id in stripe of customer in sada';


--
-- Name: COLUMN payments_trans_payments.stripe_provider_connected_account_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.stripe_provider_connected_account_id IS 'connected custome account id in stripe of tutor in sada';


--
-- Name: COLUMN payments_trans_payments.payment_method_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.payment_method_id IS 'id of the payment method which was used for the charge';


--
-- Name: COLUMN payments_trans_payments.amount; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.amount IS 'The amount is represent the value tried to charge.';


--
-- Name: COLUMN payments_trans_payments.currency; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.currency IS 'The original currency tried to charge';


--
-- Name: COLUMN payments_trans_payments.base_amount; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.base_amount IS 'The base session charge amount regarding sesson billing rate';


--
-- Name: COLUMN payments_trans_payments.stripe_fee; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.stripe_fee IS 'The fee amount calculated by stripe self';


--
-- Name: COLUMN payments_trans_payments.status; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.status IS 'The status of payment, like as ''pending'', ''available'' and ''finish''.
Value ''finish'' means we don''t care this transaction any more regarding billing progress.';


--
-- Name: COLUMN payments_trans_payments.available_on; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.available_on IS 'The available date if funds is in pending';


--
-- Name: COLUMN payments_trans_payments.type; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.type IS 'The type of transaction, ex: ''charge, create_intent''. 
Charging would be perform by 2 step, creating intent and confirm intent.
''create_intent'' means creating payment intent.
''charge'' means confirming payemnt intent.';


--
-- Name: COLUMN payments_trans_payments.net; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.net IS 'The amount that is real charged value in stripe, calculated with USD currency by subtracting the currency conversion rate and fee, stripe fee. but not considered application fee.';


--
-- Name: COLUMN payments_trans_payments.source; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.source IS 'The Id of Stripe object to which this transaction is related.';


--
-- Name: COLUMN payments_trans_payments.session_id; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.session_id IS 'ID of session that needs this payment';


--
-- Name: COLUMN payments_trans_payments.result; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.result IS 'If the payment completed successfully, "success". "fail" otherwise.';


--
-- Name: COLUMN payments_trans_payments.fail_reason; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.fail_reason IS 'The reason description about the payment failure if it failed.';


--
-- Name: COLUMN payments_trans_payments.fail_type; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.fail_type IS '2 possible values ''admin'' and ''user''
Value ''admin'' means only admin should resolve this issue if this payment failed and retry the payment.
Value ''user'' means only user should resolve this issue if this payment failed and retry the payment.';


--
-- Name: COLUMN payments_trans_payments.customer_fee; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.customer_fee IS 'The customer fee(ex: 9% of base_amount)';


--
-- Name: COLUMN payments_trans_payments.provider_fee; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.provider_fee IS 'The provider fee(ex: 15% of base_amount)';


--
-- Name: COLUMN payments_trans_payments.provider_amount; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.payments_trans_payments.provider_amount IS 'The amount to be paid for provider''s bank account';


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.products (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    name character varying(255),
    description character varying(255),
    price double precision,
    billable_by_hour boolean,
    addable_to_invoices boolean,
    addable_to_bills boolean,
    archived boolean,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone
);


ALTER TABLE public.products OWNER TO postgres_backend;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.projects (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    name character varying(255),
    customer_id character varying(36),
    archived boolean DEFAULT false,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    date_deleted timestamp with time zone,
    status character varying DEFAULT 'In Progress'::character varying
);


ALTER TABLE public.projects OWNER TO postgres_backend;

--
-- Name: COLUMN projects.status; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.projects.status IS 'Values are "In Progress" or "Completed"';


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.subscriptions (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    subscription_name character varying(30),
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    amount numeric(10,0),
    frequency character varying(10),
    subscription_id character varying(100),
    product_id character varying(100),
    price_id character varying(100),
    payment_id character varying(100),
    customer_id character varying(100),
    status character varying(100),
    trial_duration integer
);


ALTER TABLE public.subscriptions OWNER TO postgres_backend;

--
-- Name: templates; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.templates (
    id character varying(36) NOT NULL,
    template_id character varying(10),
    invoice_id character varying(36),
    color character varying(10),
    template_type character varying(10)
);


ALTER TABLE public.templates OWNER TO postgres_backend;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.user_profiles (
    id character varying(36) NOT NULL,
    user_id character varying(36),
    company_name character varying(120),
    company_logo_url character varying(120),
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    phone_number character varying(20),
    approved smallint DEFAULT 0,
    bank_account_token character varying,
    person_address_city character varying,
    person_address_line1 character varying,
    person_address_postal_code character varying,
    person_address_state character varying,
    person_dob date,
    person_id_number character varying(9)
);


ALTER TABLE public.user_profiles OWNER TO postgres_backend;

--
-- Name: COLUMN user_profiles.person_address_city; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.user_profiles.person_address_city IS 'person address city';


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.users (
    email character varying(255) NOT NULL,
    password character varying(255),
    type integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    from_google integer,
    last_login_date timestamp(6) with time zone,
    disabled_by character varying(255),
    deleted_by character varying(255),
    disabled integer DEFAULT 0,
    date_created timestamp(6) with time zone,
    date_updated timestamp(6) with time zone,
    first_name character varying(30),
    last_name character varying(30),
    time_zone character varying(50),
    verified boolean DEFAULT false NOT NULL,
    is_deleted integer DEFAULT 0,
    password_version character varying,
    welcome character varying(20)
);


ALTER TABLE public.users OWNER TO postgres_backend;

--
-- Name: COLUMN users.type; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.users.type IS '0: super admin
1: admin
2: parent
3: tutor';


--
-- Name: COLUMN users.last_login_date; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.users.last_login_date IS 'last Login Date';


--
-- Name: COLUMN users.disabled_by; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.users.disabled_by IS 'email address who disable the user';


--
-- Name: COLUMN users.deleted_by; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.users.deleted_by IS 'email address who delete the user';


--
-- Name: COLUMN users.disabled; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.users.disabled IS '0: no, 1: yes';


--
-- Name: COLUMN users.is_deleted; Type: COMMENT; Schema: public; Owner: postgres_backend
--

COMMENT ON COLUMN public.users.is_deleted IS '0: no, 1: yes';


--
-- Name: verification_token; Type: TABLE; Schema: public; Owner: postgres_backend
--

CREATE TABLE public.verification_token (
    token character varying(255) NOT NULL,
    expiry_date timestamp(6) without time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE public.verification_token OWNER TO postgres_backend;

--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.contacts (id, user_id, organization_id, name, email, job_title, phone_number, address, notes, primary_contact, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.contacts (id, user_id, organization_id, name, email, job_title, phone_number, address, notes, primary_contact, date_created, date_updated, date_deleted) FROM '$$PATH$$/4437.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.customers (id, user_id, name, industry, phone_number, website, address, notes, email, currency, account_number, ship_to_name, ship_to_address, ship_to_phone, ship_to_instructions, date_created, date_updated, date_deleted, archived, record_type) FROM stdin;
\.
COPY public.customers (id, user_id, name, industry, phone_number, website, address, notes, email, currency, account_number, ship_to_name, ship_to_address, ship_to_phone, ship_to_instructions, date_created, date_updated, date_deleted, archived, record_type) FROM '$$PATH$$/4436.dat';

--
-- Data for Name: invoice_footer; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.invoice_footer (id, user_id, invoice_footer_def_id, invoices_id, footer_order) FROM stdin;
\.
COPY public.invoice_footer (id, user_id, invoice_footer_def_id, invoices_id, footer_order) FROM '$$PATH$$/4433.dat';

--
-- Data for Name: invoice_footer_def; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.invoice_footer_def (id, user_id, footer_label, footer_description, archived) FROM stdin;
\.
COPY public.invoice_footer_def (id, user_id, footer_label, footer_description, archived) FROM '$$PATH$$/4432.dat';

--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.invoice_items (id, invoices_id, user_id, item_name, item_description, qty, unit_price, amount, product_id, "position") FROM stdin;
\.
COPY public.invoice_items (id, invoices_id, user_id, item_name, item_description, qty, unit_price, amount, product_id, "position") FROM '$$PATH$$/4429.dat';

--
-- Data for Name: invoice_tax; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.invoice_tax (id, user_id, invoice_tax_def_id, invoices_id, invoice_items_id, tax_order) FROM stdin;
\.
COPY public.invoice_tax (id, user_id, invoice_tax_def_id, invoices_id, invoice_items_id, tax_order) FROM '$$PATH$$/4431.dat';

--
-- Data for Name: invoice_tax_def; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.invoice_tax_def (id, user_id, tax_name, tax_percent, compound, recoverable, archived) FROM stdin;
\.
COPY public.invoice_tax_def (id, user_id, tax_name, tax_percent, compound, recoverable, archived) FROM '$$PATH$$/4430.dat';

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.invoices (id, user_id, invoice_number, po_number, invoice_date, payment_due_date, inv_from, inv_to, ship_to, logo, currency, footer_label, footer_description, footerhidden, date_created, date_updated, date_deleted, signature, saved, type, customer_id, project_id, record_type, parent_invoice_id, status) FROM stdin;
\.
COPY public.invoices (id, user_id, invoice_number, po_number, invoice_date, payment_due_date, inv_from, inv_to, ship_to, logo, currency, footer_label, footer_description, footerhidden, date_created, date_updated, date_deleted, signature, saved, type, customer_id, project_id, record_type, parent_invoice_id, status) FROM '$$PATH$$/4428.dat';

--
-- Data for Name: msg_emails_sent; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.msg_emails_sent (id, origin_from_system, origin_from_subsystem, origin_from_user_id, email_from, email_to, email_cc, email_bcc, subject, message, send_status, date_created, date_updated, invoice_id, dtype) FROM stdin;
\.
COPY public.msg_emails_sent (id, origin_from_system, origin_from_subsystem, origin_from_user_id, email_from, email_to, email_cc, email_bcc, subject, message, send_status, date_created, date_updated, invoice_id, dtype) FROM '$$PATH$$/4427.dat';

--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.notes (id, user_id, note_object_type, note_object_id, description, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.notes (id, user_id, note_object_type, note_object_id, description, date_created, date_updated, date_deleted) FROM '$$PATH$$/4440.dat';

--
-- Data for Name: payment_events; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payment_events (id, transaction_id, event_type, date_created) FROM stdin;
\.
COPY public.payment_events (id, transaction_id, event_type, date_created) FROM '$$PATH$$/4447.dat';

--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payment_methods (id, payment_method_id, stripe_customer_id, status, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.payment_methods (id, payment_method_id, stripe_customer_id, status, date_created, date_updated, date_deleted) FROM '$$PATH$$/4444.dat';

--
-- Data for Name: payment_prices; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payment_prices (id, price_id, active, currency, product_id, "interval", interval_count, date_created, date_updated, date_deleted, amount) FROM stdin;
\.
COPY public.payment_prices (id, price_id, active, currency, product_id, "interval", interval_count, date_created, date_updated, date_deleted, amount) FROM '$$PATH$$/4449.dat';

--
-- Data for Name: payment_products; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payment_products (id, product_id, name, description, active, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.payment_products (id, product_id, name, description, active, date_created, date_updated, date_deleted) FROM '$$PATH$$/4448.dat';

--
-- Data for Name: payments_clients; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payments_clients (stripe_customer_id, user_id, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.payments_clients (stripe_customer_id, user_id, date_created, date_updated, date_deleted) FROM '$$PATH$$/4442.dat';

--
-- Data for Name: payments_providers_accounts; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payments_providers_accounts (stripe_account_id, user_id, date_created, date_updated, date_deleted, bank_account_id, active_status, person_id, payout_status) FROM stdin;
\.
COPY public.payments_providers_accounts (stripe_account_id, user_id, date_created, date_updated, date_deleted, bank_account_id, active_status, person_id, payout_status) FROM '$$PATH$$/4450.dat';

--
-- Data for Name: payments_trans_payments; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.payments_trans_payments (id, provider_id, customer_id, stripe_customer_id, stripe_provider_connected_account_id, payment_method_id, amount, currency, base_amount, date_created, date_updated, payment_intent_id, stripe_fee, status, available_on, type, net, source, session_id, result, fail_reason, fail_type, customer_fee, provider_fee, provider_amount) FROM stdin;
\.
COPY public.payments_trans_payments (id, provider_id, customer_id, stripe_customer_id, stripe_provider_connected_account_id, payment_method_id, amount, currency, base_amount, date_created, date_updated, payment_intent_id, stripe_fee, status, available_on, type, net, source, session_id, result, fail_reason, fail_type, customer_fee, provider_fee, provider_amount) FROM '$$PATH$$/4445.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.products (id, user_id, name, description, price, billable_by_hour, addable_to_invoices, addable_to_bills, archived, date_created, date_updated, date_deleted) FROM stdin;
\.
COPY public.products (id, user_id, name, description, price, billable_by_hour, addable_to_invoices, addable_to_bills, archived, date_created, date_updated, date_deleted) FROM '$$PATH$$/4439.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.projects (id, user_id, name, customer_id, archived, date_created, date_updated, date_deleted, status) FROM stdin;
\.
COPY public.projects (id, user_id, name, customer_id, archived, date_created, date_updated, date_deleted, status) FROM '$$PATH$$/4438.dat';

--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.subscriptions (id, user_id, subscription_name, start_date, end_date, amount, frequency, subscription_id, product_id, price_id, payment_id, customer_id, status, trial_duration) FROM stdin;
\.
COPY public.subscriptions (id, user_id, subscription_name, start_date, end_date, amount, frequency, subscription_id, product_id, price_id, payment_id, customer_id, status, trial_duration) FROM '$$PATH$$/4441.dat';

--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.templates (id, template_id, invoice_id, color, template_type) FROM stdin;
\.
COPY public.templates (id, template_id, invoice_id, color, template_type) FROM '$$PATH$$/4435.dat';

--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.user_profiles (id, user_id, company_name, company_logo_url, date_created, date_updated, phone_number, approved, bank_account_token, person_address_city, person_address_line1, person_address_postal_code, person_address_state, person_dob, person_id_number) FROM stdin;
\.
COPY public.user_profiles (id, user_id, company_name, company_logo_url, date_created, date_updated, phone_number, approved, bank_account_token, person_address_city, person_address_line1, person_address_postal_code, person_address_state, person_dob, person_id_number) FROM '$$PATH$$/4434.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.users (email, password, type, id, from_google, last_login_date, disabled_by, deleted_by, disabled, date_created, date_updated, first_name, last_name, time_zone, verified, is_deleted, password_version, welcome) FROM stdin;
\.
COPY public.users (email, password, type, id, from_google, last_login_date, disabled_by, deleted_by, disabled, date_created, date_updated, first_name, last_name, time_zone, verified, is_deleted, password_version, welcome) FROM '$$PATH$$/4425.dat';

--
-- Data for Name: verification_token; Type: TABLE DATA; Schema: public; Owner: postgres_backend
--

COPY public.verification_token (token, expiry_date, user_id, id) FROM stdin;
\.
COPY public.verification_token (token, expiry_date, user_id, id) FROM '$$PATH$$/4426.dat';

--
-- Name: payment_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres_backend
--

SELECT pg_catalog.setval('public.payment_events_id_seq', 2865, true);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres_backend
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 46, true);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: payment_events payment_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.payment_events
    ADD CONSTRAINT payment_events_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_prices payment_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.payment_prices
    ADD CONSTRAINT payment_prices_pkey PRIMARY KEY (id);


--
-- Name: payment_products payment_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.payment_products
    ADD CONSTRAINT payment_products_pkey PRIMARY KEY (id);


--
-- Name: payments_clients payments_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.payments_clients
    ADD CONSTRAINT payments_clients_pkey PRIMARY KEY (user_id);


--
-- Name: payments_trans_payments payments_trans_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.payments_trans_payments
    ADD CONSTRAINT payments_trans_payments_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profile_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_token verification_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres_backend
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO postgres_backend;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO postgres_backend;


--
-- PostgreSQL database dump complete
--

